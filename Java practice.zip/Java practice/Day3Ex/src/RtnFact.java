import java.util.Scanner;
public class RtnFact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num to find factorial");
		int num=sc.nextInt();
		int f=getFact(num);
		System.out.println(num +"! = "+f);
	}
	public static int getFact(int n)
	{
		/** int fact=1;
		while(n>1)
		{
			fact=fact*n;
			n--;
		}
		return fact; **/
		
		int fact=1;
		int i=1;
		while(i<=n)
		{
			fact=fact*i;
			i++;
		}
		return fact;
		}
	}


