import java.util.Scanner;

public class BinToDec {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println(" Enter the num to find binary to equal decimal");
		int num=sc.nextInt();
		int bd=binTODec(num);
		System.out.println(" Binary To Decimalis : "+bd);

	}

	public static int binTODec(int num)
	{
		int bd=0;
		int p=0;
		while(num!=0)
		{
			int rem=num%10;
			bd=bd+rem*pow(2,p);
			p++;
			num=num/10;
		}
		return bd;
	}

	public static int pow(int i, int p) {
		// TODO Auto-generated method stub
		int pw=1;
		while(p>0)
		{
			pw=pw*i;
			p--;
		}
		return pw;
	}

}
