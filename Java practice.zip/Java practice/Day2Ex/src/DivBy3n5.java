import java.util.Scanner;

public class DivBy3n5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println(" program to count how many num are divisible ny 3 nd 5");
		int count=0;
		for(int i=1;i<=100;i++)
		{
			if((i%3==0)&&(i%5==0))
			{
				System.out.println("Divisor are "+i);
				count++;
			}
		}
		System.out.println("Count is "+count);

		}

}
