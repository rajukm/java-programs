import java.util.Scanner;

public class ThreeDigitNUm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the the   number to find Three digit or not : ");
		int num=sc.nextInt();
		
		if(num>99 && num<1000 || num<-99 && num>-1000)
			System.out.println(num +" Is Three digit num");
		else
			System.out.println(num +" IS not Three Digit num");
	}

}
