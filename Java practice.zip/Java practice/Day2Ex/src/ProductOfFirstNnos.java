import java.util.Scanner;

public class ProductOfFirstNnos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num to find first n product of natural num");
		int num=sc.nextInt();
		int product=1;
		int i=1;
		while(i<=num)
		{
			product=product*i;
			i++;
		}
		System.out.println("Product of first "+num+" natural nos : "+product);
	}

}
