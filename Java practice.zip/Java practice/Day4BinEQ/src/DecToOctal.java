import java.util.Scanner;

public class DecToOctal {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println(" Enter the num to find Decimal to octal");
		int num=sc.nextInt();
		String oct=decToOctal(num);
		System.out.println("The octal  of "+num+"  is "+oct);

	}

	public static String decToOctal(int num) {
		String oct="";
		
		while(num!=0)
		{
		 int rem=num%8;	
		 oct=rem+oct;
		 num=num/8;
		
	    }
		return oct;
	}

}
