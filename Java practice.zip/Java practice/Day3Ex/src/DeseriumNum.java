import java.util.Scanner;

public class DeseriumNum {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num to find ArmStrong ");
		int num=sc.nextInt();
		boolean rs=isDeserium(num);
		if(rs)
			System.out.println(num +" is Deserium");
		else
			System.out.println(num +" Is not Deserium");

	}
	public static boolean isDeserium(int no)
	{
		int sum=0;
		int t=no;
		int c=isCountDigit(no);
		while(no!=0)
		{
			int rem=no%10;
			sum=sum+pow(rem,c);
			c--;
			no=no/10;
		}return sum==t;
	}
	
	
	public static int isCountDigit(int no) {
		int count=0;
		while(no!=0)
		{
			count++;
			no=no/10;
		}
		return count;
	}
	public static int pow(int no, int p) {
		int pw=1;
		while(p>0)
		{
			pw=pw*no;
			p--;
		}
		return pw;

}
}

