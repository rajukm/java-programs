import java.util.Scanner;

public class LeastNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("To Find least  among  2 numbers : ");
		System.out.println("Enter 2 numbers");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		if(num1<num2)
			System.out.println(num1 +" is least");
		else if(num2<num1)
			System.out.println(num2 +" is least");
		else 
			System.out.println("Both Are Equal");
	}

}
