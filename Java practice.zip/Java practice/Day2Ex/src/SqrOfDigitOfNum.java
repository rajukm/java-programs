import java.util.Scanner;

public class SqrOfDigitOfNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Num to Find sum of square of Digit");
		int num=sc.nextInt();
		int sum=0;
		while(num!=0)
		{
			int rem=num%10;
			sum=sum+rem*rem;
			num=num/10;
		
		}
		System.out.println("Sum OF Square of  is :"+sum);

	}

}
