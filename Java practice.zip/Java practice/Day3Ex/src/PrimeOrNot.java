import java.util.Scanner;

public class PrimeOrNot {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num to find Prime OR not ");
		int num=sc.nextInt();
		boolean rs=isPrime(num);
		if(rs)
			System.out.println(num +" is prime");
		
	}
	public static boolean isPrime(int no)
	{
		int i=2;
		while(i<=no/2)
		{
			if(no%i==0)
			{
				return false;
			}
			i++;
		}
		return true;
	}

	}


