import java.util.Scanner;
public class SumOfFirstNnaturalNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num to find first n sum natural num");
		int num=sc.nextInt();
		int sum=0;
		int i=1;
		while(i<=num)
		{
			
			sum=sum+i;
			i++;
		}
		System.out.println("Sum Of "+num+" NUmber is "+sum);
	}

}
