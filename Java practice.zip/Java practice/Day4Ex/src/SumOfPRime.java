
public class SumOfPRime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
		int sum=0;
		for(int i=1;i<=1000;i++)
		{
			if(ifPrime(i))
			{
				sum=sum+i;
			}
		}
		System.out.println("Sum of Prime number is "+sum);
		
	}

	public static boolean ifPrime(int no) {
		int i=2;
		while(i<=no/2)
		{
			if(no%i==0) {
				return false;
			}
			i++;
		}return true;
		
		
	}

}
