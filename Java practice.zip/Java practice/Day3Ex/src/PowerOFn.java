import java.util.Scanner;

public class PowerOFn {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num to find its power ");
		int num=sc.nextInt();	
		System.out.println("Enter the power value ");
		int power=sc.nextInt();
		
		int poow=pow(num,power);
		System.out.println("The value of num "+num+"and power "+power+" is : "+poow);
		 

	}
	public static int pow(int n, int p)
	{
		int pw=1;
		while(p>0)
		{
			pw=pw*n;
			p--;
		}
		return pw;
	}

}
