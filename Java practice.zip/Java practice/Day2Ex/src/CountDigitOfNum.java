import java.util.Scanner;

public class CountDigitOfNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Num to Count Digit");
		int num=sc.nextInt();
		int count=0;
		
		while(num!=0)
		{
			count++;
			num=num/10;
		}
		System.out.println(count +" Total Count Of num is ");
	}

}
