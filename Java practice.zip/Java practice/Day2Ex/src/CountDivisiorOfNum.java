import java.util.Scanner;

public class CountDivisiorOfNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Num to Count divisior of num");
		int num=sc.nextInt();
		int count=0;
		
		for(int i=1;i<=num/2;i++)
		{
			if(num%i==0)
			{
				System.out.println("divisor are "+i);
				count++;
			}
		}
		
		/**while(i<=num/2)
		{
			if(num%i==0)
			{
				count++;
			}
			i++;
		}**/
		
		
		System.out.println("no of divisior of given num is "+count);

	}

}
