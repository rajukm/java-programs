import java.util.Scanner;

public class DecToHexa {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println(" Enter the num to find equal Hexadecimal");
		int num=sc.nextInt();
		String hx=decToHexaDec(num);
		System.out.println("The HexaDecimal of "+num+"  is "+hx);

	}

	public static String decToHexaDec(int num) 
	{
		String hx="";
		do
		{
			int rem=num%16;
			if(rem<16)
			{
				hx=rem+hx;
			}else
				hx=(char)(rem+55)+hx;
			num=num/16;
		}while(num!=0);
		return hx;
	}

}
