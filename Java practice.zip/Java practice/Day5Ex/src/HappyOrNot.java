import java.util.Scanner;
public class HappyOrNot {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println(" ENter the num to find Happy Or Not");
		int num=sc.nextInt();
		boolean rs=isHappy(num);
		if(rs)
			System.out.println(num +" Is happy Num");
		else
			System.out.println(num +" Is not Happy");

	}

	public static boolean isHappy(int num) {
		do
		{
			int sum=0;
			while(num!=0)
			{
				int rem=num%10;
				sum=sum+rem*rem;
				num=num/10;
			}
			num=sum;
		}while(num>9);
		return num==1 || num==7;
		
	}
	

}
