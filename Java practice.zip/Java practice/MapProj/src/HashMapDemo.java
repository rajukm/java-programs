import java.util.*;
import java.util.Map.Entry;
public class HashMapDemo {

	public static void main(String[] args) {
		Player p1=new Player("Abd",17);
		Player p2=new Player("M.S.Dhoni",7);
		Player p3=new Player("Kohli",18);
		Player p4=new Player("Watson",33);
		Player p5=new Player("M.S.Dhoni",7);
		Player p6=new Player("Kohli",18);
		
		Team t1=new Team("India");
		Team t2=new Team("RsA");
		Team t3=new Team("Australia");
		
		Map<Player,Team> map=new HashMap<Player,Team>();
		map.put(p1, t2);
		map.put(p2, t1);
		map.put(p3, t1);
		map.put(p4, t3);
		map.put(p4, t1);
		map.put(p5, t3);
		
		Set<Map.Entry<Player,Team>> st=map.entrySet();
		
		for(Map.Entry<Player, Team> ent:st)
		{
			Player p=ent.getKey();
			Team t=ent.getValue();
			System.out.println("");
			
			
			System.out.println(p.name+" plays for "+t.name);
		}//
		
	}

}
