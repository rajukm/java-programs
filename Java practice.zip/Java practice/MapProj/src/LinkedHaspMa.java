import java.util.*;
public class LinkedHaspMa {

	public static void main(String[] args)
	 {
		//LinkedHashMap<Integer,String> lhm=new LinkedHashMap<>();
		//HashMap<Integer,String> lhm=new HashMap<>();
		Hashtable<Integer,String> lhm=new Hashtable<Integer,String>();
		lhm.put(5600766, "bengaluru");
		lhm.put(5800766, "mysore");
		//lhm.put(null, "delhi"); //hashtable does not allow null 
		lhm.put(5700766, "kolk");
		lhm.put(5600766, "bengaluru");
		System.out.println(lhm);

	}

}
