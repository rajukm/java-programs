import java.util.Scanner;
public class BinTODec {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println(" Enter the num to find equal decimal");
		int num=sc.nextInt();
		String bin=decToBin(num);
		System.out.println("The binary digit of "+num+"  is "+bin);
		 

	}

	public static String decToBin(int num)
	{
	 String bin="";
	 while(num!=0)
	 {
		 int rem=num%2;
		 bin=rem+bin;
		 num=num/2;
	 }
	 return bin;
		
	}

}
