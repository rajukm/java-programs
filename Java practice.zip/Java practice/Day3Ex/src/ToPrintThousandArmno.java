
public class ToPrintThousandArmno {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int i;
		int n;
		int arm;
		int count=0;
		for(i=1;i<=1000;i++)
		{
			arm=0;
			for(n=i;n!=0;n=n/10)
			{
				arm=arm+(n%10)*(n%10)*(n%10);
			}
			if(arm==i)
			{
				count++;
				System.out.println(i +" Is ArmStrong Num");
				
			}
			
		}
		System.out.println("Count is "+count);
	}

}
