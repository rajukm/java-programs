import java.util.Scanner;

public class HexaToDec {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println(" Enter the num to find Hexadecimal to equal decimal");
		String hx=sc.next();
		int hxd=hexalTODec(hx);
		System.out.println(" HexaDecimal To Decimalis : "+hxd);


	}

	public static int hexalTODec(String hx)
	{
		int hxd=0;
		int p=0;
		for(int i=hx.length()-1;i>0;i--)
		{
			char ch=hx.charAt(i);
			if(ch>='A'&& ch<='F')
				hxd=hxd+(ch-55)*pow(16,p);
			else if(ch>='a'&& ch<='f')
				hxd=hxd+(ch-87)*pow(16,p);
			else
				hxd=hxd+(ch-48)*pow(16,p);
			p++;
		}
		return hxd;
	}

	public static int pow(int n, int p) {
		int pw=1;
		while(p>0)
		{
			pw=pw*n;
			p--;
		}
		return pw;
	}

}
