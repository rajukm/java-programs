import java.util.Scanner;
public class SpecialNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the two digit num to find Special or not");
		int num=sc.nextInt();
		
		
			int d1=num%10;
			int d2=num/10;
			
			//int sum1=d1+d2;
			//int sum2=d1*d2;
			//int result=sum1+sum2;
			
			//if(result==num)
				if((d1+d2)+(d1*d2)== num)
			
				System.out.println(num + " Is Spl Num");
			else
				System.out.println(num +" Is Not Spl num");
			
		
			
		
	}

}
