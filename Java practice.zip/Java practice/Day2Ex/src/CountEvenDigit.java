import java.util.Scanner;

public class CountEvenDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Num to Count Digit");
		int num=sc.nextInt();
		int count=0;
		
		while(num!=0)
		{
			num=num/10;
			if(num%2==0)
				count++;
		}
		System.out.println(count +" Total Count Of  even num is ");
	}

}
