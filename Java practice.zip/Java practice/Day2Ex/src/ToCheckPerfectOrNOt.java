import java.util.Scanner;

public class ToCheckPerfectOrNOt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num to Check Perfect Or Not");
		int num=sc.nextInt();
		int i=1;
		int sum=0;
		while(i<=num/2)
		{
			if(num%i==0)
			{
				sum=sum+i;
			}
			i++;
		}
		if(sum==num)
			System.out.println(num +" Is Perfect No");
		else
			System.out.println(num +" Is not perfect No");
		

	}

}
