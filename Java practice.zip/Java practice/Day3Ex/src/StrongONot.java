import java.util.Scanner;

public class StrongONot {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num to find Strong Or Not ");
		int num=sc.nextInt();
		boolean rs=isStrong(num);
		if(rs)
			System.out.println(num +" is Strong");
		else
			System.out.println(num +" Is not Strong");
		}
	public static boolean isStrong(int no)
	{
		int sum=0;
		int t=no;
		while(no!=0)
		{
			int rem=no%10;
			sum=sum+fact(rem);
			no=no/10;
		} return sum==t;
	}
	public static int fact(int n)
	{
		int f=1;
		int i=1;
		while(i<=n)
		{
			f=f*i;
			i++;
		}
		return f;
	}

}
