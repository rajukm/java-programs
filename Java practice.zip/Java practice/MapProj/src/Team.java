
public class Team {
	String name;
	public Team(String name) {
		super();
		this.name=name;
	}
	@Override
	public String toString() {
		return this.name;
	}

	
	

}
