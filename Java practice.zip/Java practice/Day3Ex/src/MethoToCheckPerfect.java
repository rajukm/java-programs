import java.util.Scanner;

public class MethoToCheckPerfect {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the num to find perfect or nor");
		int num=sc.nextInt();
		boolean rs=isPerfect(num);
		if(rs)
			System.out.println(num +" is Perfect");
		else
			System.out.println(num+" is not perfect");

	}
	public static boolean isPerfect(int no)
	{
		int sum=0;
		 for(int i=1;i<=no/2;i++)
		{
			if(no%i==0)
				sum=sum+i;
		} 
		
		/**int i=1;
		while(i<= no/2)
		{
			if(no%i==0)
			{
				sum=sum+i;
				i++;
			}
			
		} **/
		return sum==no;
		
	}

}
