import java.util.Scanner;

public class TwoDigitNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the   number to find Two digit or not : ");
		int num=sc.nextInt();
		
		if(num>9 && num<100 || num<-9 && num>-100)
			System.out.println(num +" Is two digit num");
		else
			System.out.println(num +" IS not Two Digit num");
	}

}
