import java.util.Scanner;

public class OctalToDeci {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println(" Enter the num to find octal to equal decimal");
		int num=sc.nextInt();
		int otd=ocatlTODec(num);
		System.out.println(" Octal To Decimalis : "+otd);

	}

	public static int ocatlTODec(int num)
	{
		int otd=0;
		int p=0;
		while(num!=0)
		{
			int rem=num%10;
			otd=otd+rem*pow(8,p);
			p++;
			num=num/10;
		}
		return otd;
	}

	public static int pow(int i, int p) {
		int pw=1;
		while(p>0)
		{
			pw=pw*i;
			p--;
		}
		return pw;
	}

}
