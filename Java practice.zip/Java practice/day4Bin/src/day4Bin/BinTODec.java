package day4Bin;

public class BinTODec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
