
public class Player
{
	String name;
	int no;//up
	
	public Player(String name, int no) {
		super();
		this.name=name;
		this.no=no;
	}
	

	@Override
	public String toString() {
		return this.name+"  "+this.no;
	}


	@Override
	public int hashCode() {
		
		return this.no;
	}

	@Override
	public boolean equals(Object obj) {
		boolean isSame=false;
		if(obj instanceof Player)
		{
			Player temp=(Player)obj;
			if(this.no==temp.no && this.name.equalsIgnoreCase(temp.name) )
				isSame=true;
		}
		return isSame;
	}
	
	
}
